package com.interview.formInput;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormInputApplicationTests {

	@Test
	void contextLoads() {
	}

}
