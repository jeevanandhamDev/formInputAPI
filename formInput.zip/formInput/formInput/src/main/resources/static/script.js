// src/main/resources/static/js/script.js

const API_URL = '/api/data';

// --- Function to Display Status Message ---
function displayMessage(message, isError = false) {
    const msgElement = document.getElementById('message');
    msgElement.textContent = message;
    msgElement.className = isError ? 'status-message error' : 'status-message success';
}


// --- Function to handle Deletion ---
function deleteRecord(id) {
    if (!confirm(`Are you sure you want to delete record with ID: ${id}?`)) {
        return;
    }

    fetch(`${API_URL}/${id}`, {
        method: 'DELETE'
    })
    .then(response => {
        if (response.status === 204 || response.status === 200) {
            displayMessage(`Record with ID ${id} deleted successfully.`, false);
        } else if (response.status === 404) {
             displayMessage(`Record with ID ${id} not found.`, true);
        } else {
            throw new Error(`Failed to delete data: HTTP ${response.status}`);
        }
    })
    .then(() => {
        // Refresh the table after successful deletion
        loadData();
    })
    .catch(error => {
        console.error('Deletion Error:', error);
        displayMessage(`Deletion Error: ${error.message}`, true);
    });
}


// ----------------------------------------------------------------------
// --- Function to Load and Render Data Table (SCROLL FIX APPLIED) ---
// ----------------------------------------------------------------------
function loadData() {
    const tableBody = document.getElementById('dataBody');
    tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Loading records...</td></tr>';

    fetch(API_URL)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Failed to fetch data: HTTP ${response.status}`);
            }
            return response.json();
        })
        .then(dataList => {
            tableBody.innerHTML = '';

            if (dataList.length === 0) {
                 tableBody.innerHTML = '<tr><td colspan="5" class="text-center">No data currently stored.</td></tr>';
                 return;
            }

            // Loop through the data and create table rows
            dataList.forEach(data => {
                const row = tableBody.insertRow();

                row.insertCell(0).textContent = data.id;
                row.insertCell(1).textContent = data.name;
                row.insertCell(2).textContent = data.number;
                row.insertCell(3).textContent = data.email;

                // --- Create Delete Button Cell ---
                const actionCell = row.insertCell(4);
                const deleteButton = document.createElement('button');

                deleteButton.textContent = 'Delete';
                deleteButton.className = 'btn btn-danger btn-sm';

                deleteButton.addEventListener('click', () => deleteRecord(data.id));

                actionCell.appendChild(deleteButton);
            });

            // SCROLL FIX: The explicit scroll command has been REMOVED.
            // document.getElementById('dataTable').scrollIntoView({ behavior: 'smooth', block: 'start' });

        })
        .catch(error => {
            console.error('Error fetching data:', error);
            tableBody.innerHTML = `<tr><td colspan="5" class="text-danger text-center">Error loading data: ${error.message}</td></tr>`;
        });
}


// --- Function to Handle Form Submission (POST) ---
document.getElementById('dataForm').addEventListener('submit', function(event) {
    event.preventDefault();
    displayMessage('Saving data...', false);

    const data = {
        name: document.getElementById('name').value,
        number: parseInt(document.getElementById('number').value),
        email: document.getElementById('email').value
    };

    fetch(API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(text => { throw new Error(`HTTP ${response.status}: ${text}`) });
        }
        return response.json();
    })
    .then(savedData => {
        displayMessage(`Success! Data saved with ID: ${savedData.id}`, false);
        document.getElementById('dataForm').reset();

        // Refresh the table to show the new data
        loadData();
    })
    .catch((error) => {
        console.error('Submission Error:', error);
        displayMessage(`Error saving data: ${error.message}`, true);
    });
});

// Load data when the page first loads
window.onload = loadData;